package m03.uf4.p4.p4;

import org.springframework.boot.SpringApplication;
// import org.springframework.boot.autoconfigure.SpringBootApplication;

// @SpringBootApplication
public class P4Application {

	public static void main(String[] args) {
		SpringApplication.run(P4Application.class, args);
	}

}
