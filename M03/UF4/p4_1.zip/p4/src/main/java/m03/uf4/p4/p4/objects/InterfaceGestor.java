package m03.uf4.p4.p4.objects;

public interface InterfaceGestor {
    
}
