package m03.uf4.p4.objects;

public enum Complement {
    BAIX,
    MIG,
    ALT
}
