package m03.uf4.p4.p4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
