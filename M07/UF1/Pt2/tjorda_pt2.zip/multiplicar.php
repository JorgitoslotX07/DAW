<!DOCTYPE html>
<html lang="en">
    <head> 
        <meta charset="UTF-8">
        <title>multiplicar.php</title> 
    </head> 
    <body>
        <table>
            <?php 
                $numero = 7;

                echo '<tr><td> ' . $numero . ' * 1 = ' . $numero * 1 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 2 = ' . $numero * 2 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 3 = ' . $numero * 3 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 4 = ' . $numero * 4 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 5 = ' . $numero * 5 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 6 = ' . $numero * 6 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 7 = ' . $numero * 7 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 8 = ' . $numero * 8 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 9 = ' . $numero * 9 . ' </td></tr>';
                echo '<tr><td> ' . $numero . ' * 10 = ' . $numero * 10 . ' </td></tr>';
            ?>
        </table>
    </body> 
</html> 