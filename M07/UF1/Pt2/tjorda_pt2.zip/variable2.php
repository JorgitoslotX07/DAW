<!DOCTYPE html>
<html lang="en">
    <head> 
        <meta charset="UTF-8">
        <title>variable2.php</title> 
    </head> 
    <body>
        <h1>Primer exemple de variables</h1> 
        <p> 
            <?php 
                $name = "elteunom"; 
                echo "Hola ";
                echo '<b>' . $name . '</b>'; 
                echo ", llarga vida i prosperitat"; 
            ?>
        </p>  
    </body> 
</html> 