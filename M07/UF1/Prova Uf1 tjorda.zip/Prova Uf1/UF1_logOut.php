<?php
    session_start();
    session_destroy();

    header('Location: UF1_login.php');
?>