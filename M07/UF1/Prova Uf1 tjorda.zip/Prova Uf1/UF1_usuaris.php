<html>
<head>
	<title>Prova UF1</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<?php
		include 'dadesUsuaris.php';

		session_start();
	?>
</head>
<body>
    <?php 
        if (!isset($_SESSION['usuari']) || $_SESSION['usuari'] != 'admin') {
            header('Location: UF1_login.php');
        } else {
    ?>
	<div class="container">
        <table>
            <tr>
                <th class="cabe">Usuari</th>
                <th class="cabe">Password</th>
            </tr>
            <?php 
                $par = true;
                foreach ($dadesUsuaris as $key => $value) {
                    if ($par) {
                        echo '
                            <tr><td class="par">' . $key . '</td>
                            <td class="par">' . $value . '</td></tr>
                        ';

                        $par = false;
                    }
                    else {
                        echo '
                            <tr><td class="impar">' . $key . '</td>
                            <td class="impar">' . $value . '</td></tr>
                        ';

                        $par = true;
                    }
                }
            ?>
        </table>
        <div class="logout">[<a href="UF1_logOut.php">Sortir</a>]</div>
    </div>
    <?php
        }
    ?>
</body>
</html>