<?php
$dadesUsuaris = array(	"didac" => "123456",
						"jordi" => "jordi",
						"admin" => "admin",
						"alumne" => "alumne");
?>