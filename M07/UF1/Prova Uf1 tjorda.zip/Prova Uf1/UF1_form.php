<html>
<head>
	<title>Prova UF1</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<?php
		session_start();
	?>
</head>
<body>
	<?php 

		function descuentos($euro) {
			if ($_POST['carnetJove'] || $_POST['jubilado']) {

				echo '<p>Total entrades sense descompte ................... ' . $euro .' €</p>';
				
				echo '<h2>Descomptes Aplicats</h2>';
				$descompte = 0;

				if ($_POST['carnetJove'] && $_POST['jubilado']) {
					$descompte = $euro * 0.10;
					echo '<p>Carnet Jove ................... ' . $descompte . ' €</p>';

					$descompte = $euro * 0.15;
					echo '<p>Juvilat ................... ' . $descompte . ' €</p>';

					$euro = $euro * 0.75;
				}
				else if ($_POST['carnetJove']) {
					$descompte = $euro * 0.10;
					echo '<p>Carnet Jove ................... ' . $descompte . ' €</p>';

					$euro = $euro * 0.90;
				}
				else {
					$descompte = $euro * 0.15;
					echo '<p>Juvilat ................... ' . $descompte . ' €</p>';

					$euro = $euro * 0.85;
				}

			}
			

			return $euro;
		}

		function printEntradas() {
			$platea = $_POST['numEntradesPlatea'];
			$tribuna = $_POST['numEntradesTribuna'];

			$entrada = 0;
			$euro = 0;

			echo '<p><b>Numero total de Entrades Totals: ' . $platea + $tribuna . ' </b></p>';

			for ($i=0; $i < $platea; $i++) { 
				$entrada ++;
				$euro += 30;
				echo '<p>Entrada ' . $entrada . '- Platea ................... 30 €</p>';
			}

			for ($i=0; $i < $tribuna; $i++) { 
				$entrada ++;
				$euro += 50;
				echo '<p>Entrada ' . $entrada . '- Platea ................... 50 €</p>';
			}

			$euro = descuentos($euro);

			echo '<h3>Preu Total Entrades ................... ' . $euro .' €</h3>';
		}
		

        if (!isset($_SESSION['usuari'])) {
            header('Location: UF1_login.php');
        } else {
			$form = true;
			if (!isset($_POST['nom']) || !isset($_POST['email']) || !isset($_POST['telefon'])) {
				if ($_POST['nom'] == "enviar") {
					echo 'No ha intoducido en nombre';
				}
			}
			if (isset($_POST['enviar'])) { 
				//isset($_POST['numEntradesPlatea']) || isset($_POST['numEntradesTribuna'])

				if (isset($_POST['numEntradesPlatea']) || isset($_POST['numEntradesTribuna'])) {

					$form = false;
				?>
				<h1>Dades Personales del Comprador</h1>
				<p><b>Nom: </b><?php echo $_POST["nom"]; ?></p> 
				<p><b>Email: </b><?php echo $_POST["email"]; ?></p> 
				<p><b>Telèfon: </b><?php echo $_POST["telefon"]; ?></p> 
			
				<h2>Dades de Entrades Adquirides</h2>
					<?php
						printEntradas();
				}
				else {
					echo "<h2>No has seleccionat cap Entrada!</h2>";
					echo '<h2>Per tornar al formulari fes click <a href="UF1_form.php">aqui</a></h2>';
				}
			} 
			if ($form) {
    ?>
	<div class="container">
		<div>
			<h1>Teatre de l'Institut Camí de Mar</h1>
		</div>
		<img class="imagen" alt="logoINS" src="img/LogoINS.JPG">
		<div class="formulari">
			<form action="UF1_form.php" method="POST">
			<fieldset>
				<legend>Dades comprador</legend>
				<div class="izq">
					Nom: 
				</div>	
				<div class="der">
				<?php echo '<input name="nom" type="text" placeholder="Introdueix aquí el teu nom" value="' . $_SESSION["usuari"] . '"> '; ?>
				</div>
				<div class="izq">
					Email: 
				</div>
				<div class="der">
					<input name="email" type="text" placeholder="Introdueix aquí el teu email">
				</div>
				<div class="izq">
					Telèfon: 
				</div>
				<div class="der">
					<input name="telefon" type="text" placeholder="Introdueix aquí el teu telèfon">
				</div>
			</fieldset>
			<fieldset> 
				<legend>Dades entrades</legend>
				<div class="izq">
					Platea (30€): 
				</div>
				<div class="der">
					<select name="numEntradesPlatea">
						<option value="0">0</option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
					</select>				
				</div>
				<div class="izq">
					Tribuna (50€): 
				</div>
				<div class="der">
					<select name="numEntradesTribuna">
						<option value="0">0</option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
					</select>
				</div>
				<div class="descuentos">
					<input name="carnetJove" type="checkbox"> Carnet Jove (10% Descompte)
					<br>
					<input name="jubilado" type="checkbox"> Jubilat (15% Descompte) 
				</div>
				<div class="clearfix"></div>
				<div class="botones">
					<input type="submit" name="enviar" value="Enviar"> 
					<input type="reset" value="Esborrar">
				</div>
				
			</fieldset>
			</form>
		</div>
		<div class="logout">[<a href="UF1_logOut.php">Sortir</a>]</div>
	</div>
	<?php
			}
		}
	?>
</body>
</html>