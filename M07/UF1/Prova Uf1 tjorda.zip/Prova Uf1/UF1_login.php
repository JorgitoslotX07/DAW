<html>
<head>
	<title>Prova UF1</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<?php
		session_start();
	?>
</head>
<body>
	<div class="container">
		<div>
			<h1>Teatre de l'Institut Camí de Mar</h1>
		</div>
		<?php 
			function validarLogin($user, $password) {
				include 'dadesUsuaris.php';

				foreach ($dadesUsuaris as $key => $value) {
					if ($key == $user && $value == $password) {
						return $user;
					}
				}
				return -1;
			}

			if (isset($_POST["usuari"]) && isset($_POST["password"])) {	
				$user = validarLogin($_POST["usuari"], $_POST["password"]);

				if ($user != -1) {
					$_SESSION["usuari"] = $_POST["usuari"];

					if ($user == 'admin') {
						header('Location: UF1_usuaris.php');
					}
					else {
						header('Location: UF1_form.php');
					}
				}
			}
			else {
		?>
		<img class="imagen" alt="logoINS" src="img/LogoINS.JPG">
		<div class="formulari-login">

			<form action="UF1_login.php" method="POST">
				<div class="izq">
					<label for="usuari"> Usuari: </label> 
				</div>
				<div class="der">
					<input name="usuari" id="usuari" type="text" placeholder="usuari" required>
				</div>
				<div class="izq">
					<label for="password">Password: </label>
				</div>
				<div class="der">
					<input name="password" id="password" type="password" placeholder="password" required>
				</div>
				<div class="clearfix"></div>
				<div class="botones">
					<input type="submit" value="Enviar"> 
					<input type="reset" value="Esborrar">
				</div>
			</form>
		</div>
		<?php
			}
		?>
	</div>
</body>
</html>